module.exports = {
    user: require('./user'),
    department: require('./department'),
    fromRequest: require('./requests')
}